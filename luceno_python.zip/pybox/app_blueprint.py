from flask import Blueprint, render_template, url_for

app_blueprint = Blueprint('app_blueprint',__name__)
#Variables
my_info = [
	{
	 'Year':'2010',
	 'EA' : 'Grade 6',
	 'img': '/images/bata1.jpg',
	 'Age': 13
	
	},
	{'name':'Jhon Paul Luceno',
	 'Year':'2015',
	 'EA' : '4th Year HS',
	 'img': '/images/hs1.png',
	 'Age': 16
	 
	},
	{
	 'Year':'2010',
	 'EA' : 'College',
	 'img': '/images/myself.jpg',
	 'Age': 21
	}

]

@app_blueprint.route('/')
def index():
	return render_template('index.html',my_info=my_info)

@app_blueprint.route('/about')
def about():
	return render_template('about.html')

@app_blueprint.route('/contact')
def contact():
	return render_template('contact.html')